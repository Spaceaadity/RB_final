<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct(){
		parent :: __construct();
		$this->output->enable_profiler();
		$this->load->model('User');
	}
	public function index(){
		$this->load->view('main');
	}
	public function create(){
		// var_dump($this->input->post());
		// die('create');
		$this->User->reg_user($this->input->post());
		redirect ('/');
	}
	public function login(){
		// var_dump($this->input->post());
		// die('login issue?');
		$data = $this->User->log_user($this->input->post());
		// var_dump($data);
		// die('login - data');
		if($data['logged_in']===FALSE){
			redirect ('/');
		} else {
			$this->session->set_userdata('current_user', $data);
			// die('waiting for dash to be ready!');
			redirect ('/dashboard');
		}
	}
	public function dashboard(){
		$data['user_products'] = $this->User->user_list();
		$data['other_products'] = $this->User->other_list();
		$data['userdata'] = $this->session->userdata('current_user');
		$this->load->view('dashboard', $data);
	}
	public function update($id){
		$this->User->add_to_list($id);
		redirect ('/dashboard');
	}
	public function add(){
		$this->load->view('new');
	}
	public function create_item(){
		$data = $this->User->add_item($this->input->post());
		if($data===false){
			redirect ('add');
		}else{
			redirect ('/dashboard');
		}
	}
	public function delete($id){
		// var_dump($id);
		// die('hi delete!');
		$this->User->destroy_item($id);
		redirect ('/dashboard');
	}
	public function remove($id){
		$this->User->remove_from_list($id);
		redirect ('/dashboard');
	}
	public function show($id){
		$data['product'] = $this->User->product_data($id);
		$data['product_users'] = $this->User->product_users($id);
		$this->load->view('show', $data);
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect('/');
	}
}
